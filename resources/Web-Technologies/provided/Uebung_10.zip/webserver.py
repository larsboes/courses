from flask import Flask, request, jsonify, send_from_directory
import requests
import os

webserver = Flask(__name__)

couchdb_user = os.environ["COUCHDB_USER"]
couchdb_password = os.environ["COUCHDB_PASSWORD"]
couchdb_url = os.environ["COUCHDB_URL"]

def create_databases():                
        databases = ["_users", "playlists"]
        for db in databases:                
            response = requests.put(couchdb_url+"/"+db)
            if response.status_code == 201:
                print(f"Database {db} created successfully.")
            elif response.status_code == 412:
                print(f"Database {db} already exists.")
            else:
                print(f"Failed to create database {db}: {response.status_code}, {response.text}")

@webserver.route('/')
def home():
    return send_from_directory('/pages', 'index.html')

@webserver.route('/<path:path>')
def static_pages(path):
    return send_from_directory('/', path)

@webserver.route('/playlists', methods=['GET'])
def get_playlists():
    response = requests.get(couchdb_url+"/playlists/_all_docs")
    
    if response.status_code == 200:
        playlists = [ row["id"].split(':')[1] for row in response.json()["rows"] ]
        return jsonify(playlists)
    return jsonify({"error": "Failed to retrieve playlists"}), response.status_code

@webserver.route('/playlists/<string:playlist_name>', methods=['GET'])
def get_playlist(playlist_name):
    response = requests.get(couchdb_url+"/playlists/playlist:"+playlist_name)
    if response.status_code == 200:
        playlist = { "name": response.json()["name"], "tracks": response.json()["tracks"] }
        return jsonify(playlist)
    return jsonify({"error": "Playlist not found"}), response.status_code

@webserver.route('/playlists', methods=['POST'])
def add_playlist():
    data = request.get_json()
    if not data or 'name' not in data or 'tracks' not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    doc_id = f"playlist:{data['name']}"
    playlist_doc = {
        "_id": doc_id,
        "name": data["name"],
        "tracks": data["tracks"]
    }

    response = requests.put(couchdb_url+"/playlists/"+doc_id,
        json=playlist_doc)
    
    if response.status_code in [201, 202]:  # Created or Accepted
        return jsonify({"message": f"Playlist '{data['name']}' added/updated successfully."}), 201
    return jsonify({"error": "Failed to save playlist"}), response.status_code

@webserver.route('/playlists/<string:playlist_name>', methods=['DELETE'])
def delete_playlist(playlist_name):
    doc_id = f"playlist:{playlist_name}"
    
    get_response = requests.get(
        f"{COUCHDB_URL}/{COUCHDB_DATABASE}/{doc_id}",
        auth=(COUCHDB_USER, COUCHDB_PASSWORD)
    )
    if get_response.status_code == 200:
        _rev = get_response.json().get("_rev")
        delete_response = requests.delete(
            f"{COUCHDB_URL}/{COUCHDB_DATABASE}/{doc_id}?rev={_rev}",
            auth=(COUCHDB_USER, COUCHDB_PASSWORD)
        )
        if delete_response.status_code == 200:
            return jsonify({"message": f"Playlist '{playlist_name}' deleted successfully."}), 200
    return jsonify({"error": "Playlist not found"}), 404

create_databases()

if __name__ == '__main__':
    webserver.run(host='0.0.0.0', port=8001)
