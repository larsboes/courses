const apiBaseUrl = "http://localhost:8001"; // Flask server URL

// DOM elements
const songForm = document.getElementById("track-form");
const titleInput = document.getElementById("title");
const linkInput = document.getElementById("link");
const durationInput = document.getElementById("duration");
const playlistContainer = document.getElementById("playlist");
const playlistNameInput = document.getElementById("playlist-name");
const playlistSelect = document.getElementById("playlist-select");
const savePlaylistButton = document.getElementById("save-playlist");

// Playlist state
let currentPlaylist = null;

// Fetch all playlists from the Flask server
async function fetchPlaylists() {
  try {
    const response = await fetch(`${apiBaseUrl}/playlists`);
    if (!response.ok) throw new Error("Failed to fetch playlists");
    const playlists = await response.json();
    console.info(playlists);
    // Update playlist select dropdown
    playlistSelect.innerHTML = '<option value="" disabled selected>Select a Playlist</option>';    
    playlists.forEach((playlist) => {
      const option = document.createElement("option");
      option.value = playlist;
      option.textContent = playlist;
      playlistSelect.appendChild(option);
    });
  } catch (error) {
    console.error("Error fetching playlists:", error);
  }
}

// Fetch a specific playlist by name
async function fetchPlaylist(name) {
  try {
    const response = await fetch(`${apiBaseUrl}/playlists/${name}`);
    if (!response.ok) throw new Error("Failed to fetch playlist");
    const playlist = await response.json();
    currentPlaylist = playlist;
    console.info(currentPlaylist);
    renderPlaylist();
  } catch (error) {
    console.error("Error fetching playlist:", error);
  }
}

// Add a new track to the current playlist
songForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const track = {
    title: titleInput.value.trim(),
    link: linkInput.value.trim(),
    duration: durationInput.value.trim(),
  };

  if (currentPlaylist) {
    currentPlaylist.tracks.push(track);
    renderPlaylist();
    titleInput.value = "";
    linkInput.value = "";
    durationInput.value = "";
  } else {
    alert("Please select or create a playlist first.");
  }
});

// Render the current playlist
function renderPlaylist() {
  playlistContainer.innerHTML = "";
  if (currentPlaylist && currentPlaylist.tracks) {
    currentPlaylist.tracks.forEach((track, index) => {
      const li = document.createElement("li");
      li.innerHTML = `
        ${track.title} (${track.duration})
        <a href="${track.link}" target="_blank">Listen</a>
        <button onclick="removeTrack(${index})">Remove</button>
      `;
      playlistContainer.appendChild(li);
    });
  }
}

// Remove a track from the current playlist
function removeTrack(index) {
  if (currentPlaylist) {
    currentPlaylist.tracks.splice(index, 1);
    renderPlaylist();
  }
}

// Save the current playlist to the Flask server
savePlaylistButton.addEventListener("click", async () => {
  try {
    const response = await fetch(`${apiBaseUrl}/playlists`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(currentPlaylist),
    });

    if (!response.ok) throw new Error("Failed to save playlist");
    alert("Playlist saved!");
    fetchPlaylists(); // Refresh the list of playlists
  } catch (error) {
    console.error("Error saving playlist:", error);
  }
});

// Delete the selected playlist
async function deletePlaylist(name) {
  try {
    const response = await fetch(`${apiBaseUrl}/playlists/${name}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Failed to delete playlist");
    alert(`Playlist "${name}" deleted.`);
    fetchPlaylists();
    currentPlaylist = null;
    renderPlaylist();
  } catch (error) {
    console.error("Error deleting playlist:", error);
  }
}

// Create a new playlist
document.getElementById("create-playlist").addEventListener("click", async () => {
  const playlistName = playlistNameInput.value.trim();
  if (playlistName) {
    // Create a new playlist object
    currentPlaylist = { name: playlistName, tracks: [] };

    // Render the current playlist
    renderPlaylist();

    // Add the new playlist to the dropdown
    const option = document.createElement("option");
    option.value = playlistName;
    option.textContent = playlistName;
    playlistSelect.appendChild(option);

    // Clear the input field
    playlistNameInput.value = "";
  } else {
    alert("Please enter a playlist name.");
  }
});


// Select a playlist from the dropdown
playlistSelect.addEventListener("change", (event) => {
  const selectedName = event.target.value;
  if (selectedName) {
    fetchPlaylist(selectedName);
  }
});

// Initialize the application by fetching existing playlists
fetchPlaylists();
