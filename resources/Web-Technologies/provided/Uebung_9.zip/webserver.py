from flask import Flask, request, jsonify, send_from_directory

webserver = Flask(__name__)

# In-memory Storage für unsere Playlists
playlists = {}

@webserver.route('/')
def home():
    return send_from_directory('/pages', 'index.html')

@webserver.route('/<path:path>')
def static_pages(path):
    return send_from_directory('/', path)

@webserver.route('/playlists', methods=['GET'])
def get_playlists():
    return_playlists = []
    for name, plist in playlists.items():
        return_playlists.append(name)

    return jsonify(return_playlists)

@webserver.route('/playlists/<string:playlist_name>', methods=['GET'])
def get_playlist(playlist_name):
    playlist = playlists.get(playlist_name)
    if playlist is None:
        return jsonify({"error": "Playlist not found"}), 404
    return_playlist = {'name': playlist_name, 'tracks': playlist}
    return jsonify(return_playlist)

@webserver.route('/playlists', methods=['POST'])
def add_playlist():
    # Format:
    # {
    #    "name": "My Playlist",
    #    "tracks": [
    #        {"title": "Track 1", "link": "http://example.com", "duration": "3:45"}
    #    ]
    # }
    data = request.get_json()
    if not data or 'name' not in data or 'tracks' not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    playlist_name = data['name']
    playlists[playlist_name] = data['tracks']
    return jsonify({"message": f"Playlist '{playlist_name}' added/updated successfully."}), 201

@webserver.route('/playlists/<string:playlist_name>', methods=['DELETE'])
def delete_playlist(playlist_name):
    if playlist_name in playlists:
        del playlists[playlist_name]
        return jsonify({"message": f"Playlist '{playlist_name}' deleted successfully."}), 200
    else:
        return jsonify({"error": "Playlist not found"}), 404

if __name__ == '__main__':
    webserver.run(host='0.0.0.0', port=8000)
