curl -X GET http://localhost:8001/playlists/Other%20Vibes
curl -X GET http://localhost:8001/playlists/Chill%20Vibes
