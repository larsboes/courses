curl -X POST -H "Content-Type: application/json" -d '{
  "name": "Chill Vibes",
  "tracks": [
    {
      "title": "Chill Track 1",
      "link": "http://example.com/chill_track1",
      "duration": "3:45"
    },
    {
      "title": "Chill Track 2",
      "link": "http://example.com/chill_track2",
      "duration": "4:00"
    },
    {
      "title": "Chill Track 3",
      "link": "http://example.com/chill_track3",
      "duration": "5:15"
    }
  ]
}' http://localhost:8001/playlists

curl -X POST -H "Content-Type: application/json" -d '{
  "name": "Other Vibes",
  "tracks": [
    {
      "title": "Other Track 1",
      "link": "http://example.com/other_track1",
      "duration": "2:35"
    },
    {
      "title": "Other Track 2",
      "link": "http://example.com/other_track2",
      "duration": "3:00"
    },
    {
      "title": "Other Track 3",
      "link": "http://example.com/other_track3",
      "duration": "4:05"
    }
  ]
}' http://localhost:8001/playlists
