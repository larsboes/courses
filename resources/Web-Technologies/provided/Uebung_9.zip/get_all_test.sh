curl -X GET http://localhost:8001/playlists
